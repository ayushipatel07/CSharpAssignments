﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter8
{
    ///<summary>
    ///Main method 
    ///</summary>
    class IBankAccountMain
    {
        static void Main()
        {
            Console.WriteLine(":::::::Saving Account Details::::::");
            Console.WriteLine();

            SavingAccount save = new SavingAccount();
            Console.WriteLine("Enter the amount to be deposited:");
            double amt = Convert.ToDouble(Console.ReadLine());
            save.Deposit(amt);

            Console.WriteLine("Enter the amount to be withdrawn:");
            double with = Convert.ToDouble(Console.ReadLine());
            save.Withdraw(with);

            Console.WriteLine("::::::Current Account::::::::");
            Console.WriteLine();

            CurrentAmount current = new CurrentAmount();
            Console.WriteLine("Enter the amount to be deposited:");
            double damt = Convert.ToDouble(Console.ReadLine());
            current.Deposit(damt);

            Console.WriteLine("Enter the amount to be withdrawn:");
            double cwith = Convert.ToDouble(Console.ReadLine());
            current.Withdraw(cwith);

            Console.ReadLine();
        }
    }
}
