﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session7enum2
    {
        static void Main()
        {
            foreach (string cities in Enum.GetNames(typeof(session7que2)))
            {
                Console.WriteLine(cities);
            }

            foreach (int code in Enum.GetValues(typeof(session7que2)))
            {
                Console.WriteLine(code);
            }
            Console.ReadLine();
        }
    }
}
