﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSTLib
{
    public class Class1
    {
        double amount;
        double gstper;
        double totalAmount;

      public static double calcAmount(double amount, double gstper,out double totalAmount)
        {
          
            totalAmount = amount * (gstper / 100);
            return  amount + totalAmount;

        }
    }
}
