﻿//::::WAP to print a sum of single dim array int array:::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session5que1
    {
        static void Main()
        {
            int[] num = new int[6] { 10, 20, 30, 40, 50, 60 };
           

            int sum = 0;
            for(int i=0; i<num.Length; i++)
            {
                sum = sum + num[i];   
            }
            Console.WriteLine("The sum of Array is {0}:", sum);
            Console.ReadLine();
        }
    }
}
