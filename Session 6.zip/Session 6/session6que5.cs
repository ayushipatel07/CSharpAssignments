﻿//:::::WAP to calculate GST amount using Optional Parameter:::::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session6que5
    {
        static void Main()
        {
            Console.WriteLine("Enter Amount:");
            int amount = Convert.ToInt32(Console.ReadLine());
            GST(amount);
            Console.ReadLine();

        }
        public static void GST(double amount, int per=1)
        {
             amount = amount * 0.01;
            Console.WriteLine("Total Amount is:{0}", amount);
        }
    }
}
