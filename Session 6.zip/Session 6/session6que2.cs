﻿//::::::WAP to search element from jagged array using function:::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session6que2
    {
        static void Main()
        {
            jaggedArray();
        }
        public static void jaggedArray()
        {
            int[][] nums = new int[2][];
            nums[0] = new int[3] { 10, 20, 30 };
            nums[1] = new int[2] { 40, 50 };



            foreach (var temp in nums[0])
            {
                Console.Write("{0}\t", temp);
            }
            Console.WriteLine();
            foreach (var temp in nums[1])
            {
                Console.Write("{0}\t", temp);

            }
            Console.WriteLine();
            Console.WriteLine("Enter the number:");
            int number = Convert.ToInt32(Console.ReadLine());
            int flag = 0;
            foreach (int temp in nums[0])
            {
                if (number == temp)
                {
                    flag = 1;
                }
            }
            Console.WriteLine();

            foreach (int temp in nums[1])
            {
                if (number == temp)
                {
                    flag = 1;
                }
            }
            Console.WriteLine();
            if (flag == 1)
            {
                Console.WriteLine("Search successfull, number found.");
            }
            else
            {
                Console.WriteLine("Search unsuccessfull, number not found.");
            }
            Console.ReadLine();
        }
    }
}
