﻿//:::::WAP to indentify and display even number from given array using foreach loop:::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session4que4
    {
        static void Main()
        {
            int[] num = new int[20];
            for(int i=1; i<num.Length;i++)
            {
                num[i] = i;
            }
            foreach(var temp in num)
            {
                if(temp %2 ==0)
                {
                    Console.WriteLine("Even numbers are:{0}", temp);
                }
            }
            Console.ReadLine();
        }
    }
}
