﻿// ::::::::::::::: Create a ABstract class Computer having following Functions::::::::::
// :::::1. Bootup()  2.ShutDown() ::::::::::::::::
//::::1. MainFrameComputer 2. SuperComputer 3. MicroComputer
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter8
{
   abstract class Computer
    {
        public void Bootup()
        {
            Console.WriteLine("THis is Booting Method");
        }
        public void ShutDown()
        {
            Console.WriteLine("This is ShutDown Method");
        }
      
    }
    
}
