﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class Factorialque1
    {
        static void Main()
        {
            factorial();
        }
        public static void factorial()
        {
            int fact = 1;
           
            Console.WriteLine("Enter the number:");
            int n= Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine("The factorial is:{0}", fact);
            Console.ReadLine();
        }
    }
}
