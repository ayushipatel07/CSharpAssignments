﻿//::::::WAP to display odd numbers b/w 1 to 50 using do while loop:::::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session4que2
    {
        static void Main()
        {
            Console.WriteLine("Odd numbers are:");
            int i=1;
            do
            {
               
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
                i++;

            } while (i <= 50);
            Console.ReadLine();
        }
    }
}
