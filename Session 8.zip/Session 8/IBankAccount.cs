﻿//:::::::::Bank - Requirements:::::::::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter8
{
    // Interface(IBankAccount)
    // Deposit Method
    // Withdraw Method
    public interface IBankAccount
    {
        void Deposit(double amount);
        void Withdraw(double amount);
    }
    public class SavingAccount : IBankAccount //SavingAccount is a Class
    {
        double balance = 0;
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Saving Deposited Amount: {amount}");
            Console.WriteLine($"Balance Remaining: {balance} ");
            Console.WriteLine();
        }
        public void Withdraw(double amount)
        {
            if(amount <=balance)
            {
                balance = balance - amount;
                Console.WriteLine($"Saving withdraw amount : {amount}");
                Console.WriteLine($"Balance Remaining : {balance}");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Cannot withdraw amount");
                Console.WriteLine($"Balance Remaining : {balance}");
            }
        }
    }
    public class CurrentAmount : IBankAccount   // CurrentAccount is a class
    {
        double balance = 6000;
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Current Deposited Amount : {amount}");
            Console.WriteLine($"Balance Remaining : {balance}");
            Console.WriteLine();
        }
        public void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance = balance - amount;
                Console.WriteLine($"Saving withdraw amount : {amount}");
                Console.WriteLine($"Balance Remaining : {balance}");
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine("Cannot withdraw amount");
                Console.WriteLine($"Balance Remaining : {balance}");
            }
        }
    }
}
