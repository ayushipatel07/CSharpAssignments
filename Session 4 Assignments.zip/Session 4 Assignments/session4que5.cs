﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session4que5
    {
        static void Main()
        {
            
            Console.WriteLine("Enter the number:");
            int num = Convert.ToInt32(Console.ReadLine());
            for(int i=1; i<=10; i++ )
            {
                Console.WriteLine("----------");
                Console.WriteLine( num * i);
            }
            Console.ReadLine();
        }
    }
}
