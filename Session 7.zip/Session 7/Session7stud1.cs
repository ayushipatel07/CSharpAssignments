﻿//:::::WAP to maintain City Names and STD codes using Enum

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class Session7stud1
    {
        static void Main()
        {
            StudentsInfo std = new StudentsInfo(101, "ayushi", "F", 9876543210);
            Console.WriteLine(std.display());
            Console.ReadLine();
        }
    }
}
