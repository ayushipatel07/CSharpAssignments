﻿//::::::WAP to make sum of each row for multi dim array and print them ::::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session5que4
    {
        static void Main()
        {
            char[,] num = new char[3, 3] { { 'a', 'b', 'c' }, { 'd', 'e', 'f' }, { 'g', 'h', 'i' } };
            Console.WriteLine("-----------");
            Console.WriteLine("Character Array is:");
            for(int i=0; i<3; i++)
            {
                for(int j=0; j<3; j++)
                {
                    Console.WriteLine("\t{0}", num[i, j]);
                }
                Console.WriteLine();
            }
            Console.WriteLine("---------");
            
            for(int i=0;i<3;i++)
            {
                for(int j=0;j<3;j++)
                {
                    Console.Write("{0}\t",Convert.ToInt32(num[i, j]));
                }
                Console.WriteLine();
            }
           
            Console.ReadLine();
        }
      
    }
}
