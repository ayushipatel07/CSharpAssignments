﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace typeofProgram
{
    class Task2
{
        static void Main()
        {
            char a='A';
            Console.WriteLine("The ASCII value is: {0}", (int)a);
            int num = Convert.ToInt16(a);
            Console.WriteLine("The character is : {0}", a);
            Console.ReadLine();
        }
}
}
