﻿//::::::WAP to calculate simple interest and total payable amount including interest using out parameter

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session6que4
    {
        
        static void Main()
        {

            Console.WriteLine("Enter the principle amount:");
            int  p = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the rate:");
            int   r = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the time:");
            int    t = Convert.ToInt32(Console.ReadLine());
            double amt;
            Console.WriteLine("The amount is:{0}",Amount(p,r,t, out amt));
            Console.ReadLine();

        }

        public static double Amount(int p, int r, int t, out double  amt)
        {

           double SI;
            SI = (p * r * t) / 100;

            Console.WriteLine("The Simple Interest is:{0}", SI);

         
            amt = p + SI;
            
            return amt;
           
        }
    }
}
