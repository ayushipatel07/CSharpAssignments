﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session5que5
    {
        static void Main()
        {
            int sum = 0;
            int[,] num = new int[3, 3];
            Console.WriteLine("Enter the elements:");
            for(int i=0;i<3;i++)
            {
               for(int j=0;j<3;j++)
                {
                    num[i, j] = Convert.ToInt32(Console.ReadLine());
                }
                Console.WriteLine();
            }
            Console.WriteLine("----------");
            for(int i=0;i<3;i++)
            {
                for(int j=0;j<3;j++)
                {
                    sum = sum + num[i, j];
                }
                Console.WriteLine("The sum is:{0}\t", sum);
            }
            Console.WriteLine();
            Console.ReadLine();
        }
    }
}
