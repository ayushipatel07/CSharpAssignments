﻿//::::::::::::::::FORUM REQUIREMENTS::::::::::::::::::::::::::::::::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter8
{
    class User
    {
       private long id;
       private string name;
       private string emailId;
       private string dateofbirth;

        public User(long id, string name, string emailId, string dateofbirth) // Parameterized constructor
        {
            this.id = id;
            this.name = name;
            this.emailId = emailId;
            this.dateofbirth = dateofbirth;
        }
        public override string ToString() // Override the ToString() Method
        {
            return $"Id = {id}\n Name = {name}\n EmailId = {emailId}\n Date of Birth = {dateofbirth}";
        }
        public static bool ValidateEmail(List<User> users, string email)
        {
            foreach(User temp in users)
            {
                if(temp.emailId == email)
                {
                    return true;
                }

            }
             return false;
            
        }
        static void Main()    // Main Method
        {
            List<User> userlist = new List<User>();
            int option;
            do
            {
                Console.WriteLine("------------------------");
                Console.WriteLine("Enter id:");
                int i = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("Enter the name:");
                string nm = (Console.ReadLine());


                Console.WriteLine("Enter Email Id:");
                string ei = (Console.ReadLine());

                bool result = ValidateEmail(userlist, ei);
                while (result)
                {

                    Console.WriteLine("OOPs! THis email is not available");
                    ei = Console.ReadLine();
                    result = ValidateEmail(userlist, ei);
                }

                Console.WriteLine("Enter Date of Birth:");
                string dob = (Console.ReadLine());

                Console.WriteLine(":::::::::::::User Details:::::::");
                Console.WriteLine();
                User usr = new User(i, nm, ei, dob);

                Console.WriteLine(usr.ToString());
                Console.WriteLine("Do you want to add more Users:");
                Console.WriteLine("1. Add\n 2. Exit");
                option = Convert.ToInt32(Console.ReadLine());

                userlist.Add(usr);
            } while (option != 2);

                Console.ReadLine();
        }
    }
}
