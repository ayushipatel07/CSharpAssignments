﻿//::::WAP to decide whether the person is major or minor using ternary operator:::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class task4
    {
        static void Main()
        {
            Console.WriteLine("Enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(age >= 18 ? "you are major" : "you are minor");
            Console.ReadLine();
        }
    }
}
