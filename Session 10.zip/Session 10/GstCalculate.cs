﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSTLib;
namespace TestGST
{
    /// <summary>
    /// Main Method
    /// </summary>
    class GstCalculate
    {
        static void Main()
        {
            Console.WriteLine("Enter the amount:");
            double amt = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter GST percentage:");
            double per = Convert.ToDouble(Console.ReadLine());

            double cgst;
            Class1 g = new Class1();
            Console.WriteLine($"Total amount, GSt {per}% is : {Class1.calcAmount(amt, per, out cgst)}");
            Console.WriteLine($"Total GST on {amt} is = {cgst}");
            Console.ReadLine();
        }
    }
}
