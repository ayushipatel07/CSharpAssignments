﻿//:::::WAP to display sum of diagonal elements::::::::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session5que2
    {
       
        static void Main()
        {
            int sum = 0;
            int[,] num = new int[3, 3];
            for(int i=0; i<3; i++)
            {
                for( int j=0; j<3; j++)
                {
                    num[i, j] = Convert.ToInt32(Console.ReadLine());
                }

            }
            Console.WriteLine("-------");
            Console.WriteLine("Array is:");
            for(int i=0; i<3; i++)
            {
                for(int j=0; j<3; j++)
                {
                    Console.WriteLine("{0}\t", num[i, j]);
                }
            }
            for(int i=0; i<3; i++)
            {
                for(int j=0; j<3; j++)
                {
                   if(i==j)
                    {
                      
                        sum = sum + num[i, j];
                       
                    }
                }
              
            }
            Console.WriteLine("--------");
            Console.WriteLine("The sum is :{0}\t", sum);
            Console.ReadLine();
        }
    }
}
