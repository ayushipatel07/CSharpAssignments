﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter8
{
    class MainComputer
    {
        static void Main()
        {
            SuperComputer sc = new SuperComputer();
            sc.Bootup();
            sc.supercomp();
            sc.ShutDown();
            Console.WriteLine();
            Console.WriteLine("---------------------");
            MainFrameComputer mn = new MainFrameComputer();
            mn.Bootup();
            mn.mainframe();
            mn.ShutDown();
            Console.WriteLine();
            Console.WriteLine("-------------------------");
            MicroComputer mic = new MicroComputer();
            mic.Bootup();
            mic.micro();
            mic.ShutDown();
            Console.WriteLine();
            Console.WriteLine("--------------------------");
            Console.ReadLine();
            
        }
    }
}
