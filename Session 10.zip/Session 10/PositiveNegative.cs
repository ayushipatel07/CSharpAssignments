﻿//:::WAP to check number is positive and negative using Extension Function:::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
   public static class PositiveNegative
    {

        public static void IsPositiveNegative(this int i, int value)
        {
            // return i > value;
            if (i > 0)
            {
                value = value + i;
                Console.WriteLine("Number is Positive {0}", value);
            }
            else
            {
                Console.WriteLine("Number is Negative");
            }

        }
      class ExtensionMethod
        {
            static void Main()
            {
                int i = 10;
                i.IsPositiveNegative(3);
               Console.ReadLine();
            }
        }
    }
}
