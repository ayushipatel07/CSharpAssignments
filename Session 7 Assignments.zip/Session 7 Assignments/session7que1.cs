﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session7que1
    {

    }
        struct StudentsInfo
        {
            int rollNumber;
            string name;
            string gender;
            long mobile;

            public  StudentsInfo(int rollNumber, string name, string gender, long mobile)
            {
                this.rollNumber = rollNumber;
                this.name = name;
                this.gender = gender;
                this.mobile = mobile;
            }
            public string display()
            {
                return string.Format("Roll number = {0} Name = {1} Gender = {2} Mobile = {3}", rollNumber, name, gender, mobile);
            }
        }
    }

