﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
///<summary>
///TO inherit the abstract class Computer
///</summary>
namespace chapter8
{
    class SuperComputer: Computer
    {
        public void supercomp()
        {
            Console.WriteLine("THis is Super Computer");
        }

    }
}
