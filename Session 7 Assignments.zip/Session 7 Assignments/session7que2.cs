﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
 public  enum session7que2
    { 

       Pune = 020, Mumbai = 111, Aurangabad = 0240, Jabalpur = 0761
     };
 }
