﻿//:::::WAP to calculate Area of circle using constants:::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace typeofProgram
{
    class task1
{
        static void Main()
        {
         const  double PI = 3.14;
           double area;
            int r = 3;
            area = PI * r * r;
            Console.WriteLine("The area of circle is:",area);
            Console.ReadLine();
        }
}
}
