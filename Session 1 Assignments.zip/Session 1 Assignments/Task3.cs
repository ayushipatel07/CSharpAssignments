﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace typeofProgram
{
    class Task3
{
        static void Main()
        {
            double dollar = 3;
            double rupees;
            rupees = dollar * 71.76;
            Console.WriteLine("In rupees:" + rupees);
            Console.WriteLine("In dollar:" + (rupees / dollar));
            Console.ReadLine();
        }    
}
}
