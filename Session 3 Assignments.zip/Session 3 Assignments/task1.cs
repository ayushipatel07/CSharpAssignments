﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class task1
    {
        static void Main()
        {
            
            Console.WriteLine("Enter your age:");
            int age = Convert.ToInt32(Console.ReadLine());
            if( age < 18)
            {
                Console.WriteLine("Person is minor");
            }
            else
            {
                Console.WriteLine("person is major");
            }
            Console.ReadLine();
        }
    }
}
