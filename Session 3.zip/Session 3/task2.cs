﻿//:::::::::WAP to decide grade according to percentage using if-else if-else:::::::::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class task2
    {
        static void Main()
        {
            Console.WriteLine("Enter your Percentage:");
            int per = Convert.ToInt32(Console.ReadLine());
            if(per > 35)
            {
                Console.WriteLine("your grade is 'D'");
            }
            else if(per >50)
            {
                Console.WriteLine("your grade is 'C'");
            }
            else if(per > 65)
            {
                Console.WriteLine("your grade is 'B'");
            }
            else if(per > 75)
            {
                Console.WriteLine("your grade is 'A'");
            }
            else
            {
                Console.WriteLine("Fail");
            }
            Console.ReadLine();

        }
    }
}
