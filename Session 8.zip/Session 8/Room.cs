﻿//:::Create a class Room, mark all the attributes as private, generate appropriate properties:::


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chapter8
{
    class Room
    {
       private int number;
        private int floor;
        private string type;
        private int capacity;
        private DateTime bookedTime;
        private double price;

        public  Room()
        {
            Console.WriteLine("Default constructor of Room Class");
        }

        public Room(int number, int floor, string type, int capacity, DateTime bookedTime, double price)
        {
            this.number = number;
            this.floor = floor;
            this.type = type;
            this.capacity = capacity;
            this.bookedTime = bookedTime;
            this.price = price;
        }
        public int num
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }

        public int flr
        {
            get
            {
                return floor;
            }
            set
            {
                floor = value;
            }
        }

        public string typ
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }

        public int cap
        {
            get
            {
                return capacity;
            }
            set
            {
                capacity = value;
            }
        }
        public DateTime book
        {
            get
            {
                return bookedTime;
            }
            set
            {
                bookedTime = value;
            }
        }

        public double pri
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }
        public override string ToString()
        {
            return $"Number = {number}\n Floor = {floor}\n Type = {type}\n" +
                $" Capacity = {capacity}\n Bookedtime = {bookedTime}\n Price = {price}";
        }
        static void Main()
        {
           
            Console.WriteLine("Enter Room Number:");
            int rn = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Floor:");
            int fl = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Type of Room AC/NON-AC");
            string ty = Console.ReadLine();

            Console.WriteLine("Enter the Capacity:");
            int cp = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the BookedTime:");
            DateTime bookt = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter the total Price:");
            int pc = Convert.ToInt32(Console.ReadLine());
            Room room = new Room(rn, fl, ty, cp, bookt, pc);

            Console.WriteLine( room.ToString());
            Console.ReadLine();
                
        }
    }
}
