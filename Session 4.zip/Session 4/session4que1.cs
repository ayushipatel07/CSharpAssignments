﻿//::::::WAP to display numbers in reverse order from 50 to 1 using for loop :::::

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session4que1
    {
        static void Main()
        {
            Console.WriteLine("Reverse order of numbers are:");
            for(int i=50; i>=1; i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
