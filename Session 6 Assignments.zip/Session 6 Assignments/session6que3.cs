﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace session3
{
    class session6que3
    {
        static void Main()
        {
            simpleInterest();
        }
        public static void simpleInterest()
        {

            int p = 0, r = 0, t = 0;
            Console.WriteLine("Enter the principle amount:");
            p= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the rate:");
            r= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the time:");
            t= Convert.ToInt32(Console.ReadLine());

            int SI;
            SI = (p * r * t) / 100;
            
            Console.WriteLine("The Simple Interest is:{0}", SI);
            Console.ReadLine();

        }
    }
}
